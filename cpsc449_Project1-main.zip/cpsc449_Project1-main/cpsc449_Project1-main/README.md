# This project is for CPSC 449 - Web Backend Engineering.

We will be building a RESTful API with Flask - Error Handling, Authentication, and
File Handling with Public and Admin Routes

Group Members:

<li>Anshika Khandelwal</li>
<li>Pallavi Thorat</li>

To run the project:

 Run the project with the command.
`python app.py`

Screenshots are attached in the assets folder
